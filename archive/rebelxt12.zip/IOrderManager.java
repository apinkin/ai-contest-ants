
public interface IOrderManager {
    boolean issueOrder(Order order);
}
