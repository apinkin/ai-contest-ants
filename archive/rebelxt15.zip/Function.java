
public interface Function<K, V> {
    V apply(K arg);
}
